from entity import Game


def main():
    driver = Game()


if __name__ == "__main__":
    main()
