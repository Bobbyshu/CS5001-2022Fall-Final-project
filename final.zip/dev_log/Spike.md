# Dev log
### **Milestone2**
**1. Background**\
1.1 Intro pageg
```python
turtle.register_shape()
turtle.Turtle(shape=picture)
screen.title("Welcome to the turtle zoo!")
turtle.setup(width=_CFG['width'], height=_CFG['height'], startx=_CFG['leftright'], starty=_CFG['topbottom']
time.sleep(secs)
```
1.2 assess value
```
screen.textinput("NIM", "Name of first player:")
turtle.numinput(title, prompt, default=None, minval=None, maxval=None)
```
1.3 Main page\
(modified in 11/20)new a class to execute those drawing operation
```
screen.textinput("NIM", "Name of first player:")
turtle.numinput(title, prompt, default=None, minval=None, maxval=None)
turtle.onclick(fun, btn=1, add=None)
```
1.4 LeaderBoard\
read info from leaderboard.txt
```
classmethod datetime.now(tz=None)
```
